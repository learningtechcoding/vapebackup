<?php

namespace App\Http\Controllers;

use App\Models\Contact;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use App\Mail\ContactMessage;

class ContactController extends Controller
{

    public function sendMessage(Request $request)
    {
        // dd($request->all());
        $validatedData = $request->validate([
            'name' => 'required|string',
            'email' => 'required|email',
            'message' => 'required|string',
        ]);

        $adminEmail = "nazeermohsin187@gmail.com";

        try {
            // Send email to the user
            Mail::send('emails.contact', [
                'name' => $validatedData['name'],
                'userMessage' => $validatedData['message']
            ], function ($message) use ($validatedData) {
                $message->to($validatedData['email'])
                    ->subject("Contact Form Message from {$validatedData['name']}");
            });

            // Send email to the admin
            Mail::send('emails.contact', [
                'name' => $validatedData['name'],
                'userMessage' => $validatedData['message']
            ], function ($message) use ($adminEmail) {
                $message->to($adminEmail)
                    ->subject('New Contact Form Message');
            });

            \Log::info('Emails sent successfully', ['email_data' => $validatedData]);

            // Flash success message and redirect back
            return redirect()->back()->with('success', 'Emails sent successfully.');
        } catch (\Exception $e) {
            \Log::error('An error occurred in sendMessage', [
                'error_message' => $e->getMessage(),
                'error_code' => $e->getCode(),
                'trace' => $e->getTraceAsString(),
            ]);

            // Flash error message and redirect back
            return redirect()->back()->with('error', 'Failed to send email.');
        }
    }
}
