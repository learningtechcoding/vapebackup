<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Message Received</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            color: #333;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }

        .email-container {
            width: 100%;
            max-width: 600px;
            margin: 0 auto;
            background-color: #ffffff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .header {
            background-color: #0962ca;
            color: #ffffff;
            padding: 20px;
            text-align: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
            color: #fa8b1b;
        }

        .content {
            padding: 20px;
            line-height: 1.6;
        }

        .content h2 {
            color: #0962ca;
        }

        .content p {
            color: #333;
        }

        .content blockquote {
            margin: 15px 0;
            padding: 15px;
            background-color: #f0f4f9;
            border-left: 5px solid #0962ca;
            font-style: italic;
            color: #555;
        }

        .footer {
            background-color: #f0f4f9;
            color: #333;
            padding: 20px;
            text-align: center;
            font-size: 14px;
            border-top: 1px solid #e0e0e0;
        }
    </style>
</head>

<body>
    <div class="email-container">
        <div class="header">
            <h1>Thank You for Contacting Us!</h1>
        </div>

        <div class="content">
            <h2>Hi, <?php echo e($name); ?>!</h2>
            <p>We appreciate you reaching out to us. Here’s a copy of your message:</p>

            <blockquote>
                "<?php echo e($userMessage); ?>"
            </blockquote>

            <p>Our team will review your message and respond to you as soon as possible.</p>
            <p>If you need immediate assistance, feel free to contact our support team at any time.</p>
        </div>

        <div class="footer">
            <p>Best regards,</p>
            <p>The Support Team</p>
            <p>Company Name | Contact: support@example.com</p>
        </div>
    </div>
</body>

</html>
<?php /**PATH D:\RahimGallery\Website\backend\resources\views/emails/contact.blade.php ENDPATH**/ ?>