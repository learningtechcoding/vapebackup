<footer class="footer-section mt-5">
    <div class="container">
        <div class="row mar-top60 mar-bottom30">

          <!-- Nav Links Section -->
          <div class="col-md-3 col-sm-6 mb-3 col-xs-12 owl-ba">
                <div class="">
               <div>
               <img class="site_logo dark-logo" alt="Site Logo"
                                                style="height: 70px; width: auto;" src="assets/img/Rahim.png" />

               </div>
                    <p class="text-white">At Rahhim Designs, we transform your vision into reality
                                            with custom decor inspired by sub-continent, Arab, and Oriental art,
                                            creating spaces that embody beauty and meaning.</p>
                </div>
            </div>
        <!-- Company Location Section -->
            <div class="col-md-4 col-sm-6 mb-3 col-xs-12 owl-ba mar-bottom30">
                <div class="footer-box ba">
                    <h3 class="footer-color">Company Location</h3>
                    <div class="address-box pad-top20">
                        <div class="col-md-2 col-xs-2">
                            <i class="footer-icon fa fa-map-marker" aria-hidden="true"></i>
                        </div>
                        <div class="col-md-10 col-xs-10">
                            <p class="footer-box1-text">USA</p>
                        </div>
                    </div>
                    <div class="contact-box mar-top10">
                        <div class="col-md-2 col-xs-2">
                            <i class="footer-icon fa fa-phone" aria-hidden="true"></i>
                        </div>
                        <div class="col-md-10 col-xs-10">
                            <p class="footer-icon footer-box1-text">832-9980202</p>
                        </div>
                    </div>
                    <div class="contact-box1 mar-top10">
                        <div class="col-md-2 col-xs-2">
                            <i class="footer-icon fa fa-envelope-o" aria-hidden="true"></i>
                        </div>
                        <div class="col-md-10 col-xs-10 bottom-size">
                            <p class="footer-box1-text">info@RahhimDesigns.com</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Social Links Section -->

              <!-- Nav Links Section -->
              <div class="col-md-2 col-sm-6 mb-3 col-xs-12 owl-ba">
                <div class="footer-box">
                    <h3 class="footer-color">Nav Links</h3>
                    <ul class="footer-3-ul">
                        <li><a href="/"><i class="fa fa-angle-right" aria-hidden="true"></i> Home</a>
                        </li>
                        <li><a href="/"><i class="fa fa-angle-right" aria-hidden="true"></i> About
                                Us</a></li>
                        <li><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i>
                                Services</a></li>
                        <li><a href="<?php echo e(url('contact_us')); ?>"><i class="fa fa-angle-right" aria-hidden="true"></i>
                                Contact</a></li>
                    </ul>
                </div>
            </div>
            <!-- Nav Links Section -->
            <div class="col-md-3 col-sm-6 mb-3 col-xs-12 owl-ba">
                <div class="footer-box">
                    <h3 class="footer-color">Social Link</h3>
                    <ul class="footer-3-ul">
                        <li>
                            <a href="https://www.facebook.com/woodgallery?mibextid=LQQJ4d" target="_blank">
                                <i class="fa fa-facebook" aria-hidden="true"></i> Facebook
                            </a>
                        </li>
                        <li>
                            <a href="https://www.instagram.com/rahhimdesign/profilecard/?igsh=MXZ1dWU1Njl1Nzh2YQ=="
                                target="_blank">
                                <i class="fa fa-instagram" aria-hidden="true"></i> Instagram
                            </a>
                        </li>


                    </ul>
                </div>
            </div>



        </div>
    </div>
</footer>
<?php /**PATH D:\RahimGallery\latest\resources\views/footer.blade.php ENDPATH**/ ?>