<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="keywords" content="HTML5 Template" />
    <meta name="description" content="Interrio - Corporate Architecture and Interior Design, Responsive Html5 Template" />
    <meta name="viewport" content="width=device-width, initial-scale=0.67, maximum-scale=0.67" />

    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet" />

    <title>
        RAHHIM DESIGN
    </title>
    <link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon" />
    <link rel="icon" href="assets/img/favicon.ico" type="image/x-icon" />
    <!-- Master Css -->
    <link href="main.css" rel="stylesheet" />
    <style>
        .whatsapp-icon {
            position: fixed;
            /* Fixed positioning */
            bottom: 20px;
            /* Distance from the bottom */
            right: 10px;
            /* Distance from the right */
            background-color: white;
            /* Background color */
            border-radius: 50%;
            /* Circular shape */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            /* Optional shadow */
            padding: 15px;
            /* Increased padding around the icon */
            z-index: 1000;
            /* Ensure it stays on top */
        }

        .whatsapp-icon i {
            font-size: 40px;
            /* Increased size of the icon */
            color: green;
            /* Color of the icon */
        }

        /* Additional styles for your content can go here */
        h1 {
            color: #333;
        }

        /* Optional: Add styles to make the images responsive */
        .img-fluid {
            max-width: 100%;
            height: auto;
        }

        /* Style for the category sections */
        .section {
            display: none;
            /* Hide all sections initially */
            margin-top: 20px;
        }


        /* Optional: Add hover effect for category buttons */
        .filter {
            margin-bottom: 10px;
        }

        .fixed-size {
            width: 390px;
            /* Fixed width */
            height: 300px;
            /* Fixed height */
            object-fit: cover;
            /* Ensures images are not distorted and will be cropped if necessary */
        }

        .image-row {
            gap: 15px;
            /* Adjust the gap between columns */
        }


        .img-container {
            width: 100%;
            /* Ensure the container takes the full width of the column */
            height: 200px;
            /* Set a fixed height for the images */
            overflow: hidden;
            /* Hide any overflow from the image */
        }

        .img-container img {
            width: 390px;
            /* Fixed width */
            height: 300px;
            /* Fixed height */
            object-fit: cover;
            /* Ensure the image maintains its aspect ratio while covering the container */
        }

        .pregap-tecx {
            text-align: left;
            /* Default alignment */
        }

        @media (max-width: 768px) {
            .pregap-tecx {
                text-align: center;
                /* Center text on smaller screens */
            }
        }
    </style>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body>
    <a href="https://api.whatsapp.com/send?phone=+1(832)998-0202&text=Hello!%20I%20would%20like%20to%20get%20in%20touch%20with%20you."
        target="_blank" class="whatsapp-icon">
        <i class="fab fa-whatsapp"></i>
    </a>


    <div class="dark-version">
        <!--//==top header Start==//-->
        <!--//==preloader Start==//-->
        <div id="loading">
            <div id="loading-center">
                <div id="loading-center-absolute">
                    <div id="object"></div>
                    <h3 class="pad-top15 heading-color">Loading</h3>
                </div>
            </div>
        </div>
        <!--//==preloader End==//-->
        <header id="main-header">
            <div class="top-header pad-top10 pad-bottom10">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-12 text-left">
                            <ul class="top-bar-icon">
                                <li>
                                    <a href=""><i class="fa fa-phone" aria-hidden="true"></i>832-9980202</a>
                                </li>
                                <li>
                                    <a href=""><i class="fa fa-envelope-o"
                                            aria-hidden="true"></i>info@RahhimDesigns.com</a>
                                </li>
                            </ul>
                        </div>
                        <div class="col-md-6 col-sm-6 col-xs-12 text-right">
                            <ul class="top-right-icon">
                                <li>
                                    <a href="https://www.facebook.com/woodgallery?mibextid=LQQJ4d"><i
                                            class="fa fa-facebook" aria-hidden="true"></i></a>
                                </li>
                                <li>
                                    <a
                                        href="https://www.instagram.com/rahhimdesign/profilecard/?igsh=MXZ1dWU1Njl1Nzh2YQ=="><i
                                            class="fa fa-instagram" aria-hidden="true"></i></a>
                                </li>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!--//==top header end==//-->
            <!--//==mega menu start==//-->
            <div id="main-menu" class="wa-main-menu">
                <!-- Menu -->
                <div class="wathemes-menu relative">
                    <!-- navbar -->
                    <div class="navbar navbar-default navbar-bg-dark" role="navigation">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="navbar-header pad-top15 pad-bottom15">
                                        <!-- Button For Responsive toggle -->
                                        <button type="button" class="navbar-toggle" data-toggle="collapse"
                                            data-target=".navbar-collapse">
                                            <span class="sr-only">Toggle navigation</span>
                                            <span class="icon-bar"></span>
                                            <span class="icon-bar"></span>
                                            <span class="icon-bar"></span>
                                        </button>
                                        <!-- Logo -->
                                        <a class="navbar-brand" href="/"
                                            style="display: flex; align-items: center;">
                                            <img class="site_logo dark-logo" alt="Site Logo"
                                                style="height: 70px; width: auto;" src="assets/img/Rahim.png" />
                                            <img class="site_logo light-logo" alt="Site Logo"
                                                style="height: 70px; width: auto;" src="assets/img/Rahim.png" />
                                            <span
                                                style="font-size: 24px; margin-left: 10px; font-weight: bold; color: white;">RAHHIM
                                                DESIGNS</span>
                                        </a>


                                    </div>
                                    <!-- Navbar Collapse -->
                                    <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <!-- navbar-collapse -->
                                </div>
                                <!-- col-md-12 -->
                            </div>
                            <!-- row -->
                        </div>
                        <!-- container -->
                    </div>
                    <!-- navbar -->
                </div>
                <!--  Menu -->
            </div>
            <!--//==mega menu end==//-->
        </header>
        <!--//========slider start=========//-->
        <section class="slider-section">
            <div id="main-slider" class="owl-carousel owl-theme">
                <div class="item">
                    <figure class="dark-theme">
                        <img src="assets/img/1.jpg" alt="" style="width: 80%; height: auto;" />
                    </figure>
                    <div class="slider-section-1 text-left">
                        <div class="container">
                            <div class="col-md-8 slider-box1">
                                <div class="row">
                                    <div class="main-slider-heading">
                                        <h1 class="heading-wa">
                                            Creative <span class="yellow">Interior</span> Designs
                                        </h1>
                                    </div>
                                    <div class="slider-section-1-text">
                                        <p class="pregap-tecx">At Rahhim Designs, we transform your vision into reality
                                            with custom decor inspired by sub-continent, Arab, and Oriental art,
                                            creating spaces that embody beauty and meaning.</p>
                                        <p class="pregap-tecx">Our team brings your ideas to life with respect for
                                            cultural heritage, crafting spaces that reflect your unique vision and
                                            aspirations.</p>
                                    </div>
                                    <a href="" class="itg-button mar-top20">Explore Now</a>
                                    <a href="<?php echo e(url('contact_us')); ?>" class="itg-button mar-top20 mar-left15">Contact
                                        Us</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <figure class="dark-theme">
                        <img src="assets/img/2.jpg" alt="" style="width: 80%; height: auto;" />
                    </figure>
                    <div class="slider-section-1 text-left">
                        <div class="container">
                            <div class="col-md-8 slider-box1">
                                <div class="row">
                                    <div class="main-slider-heading">
                                        <h1 class="heading-wa">
                                            Creative <span class="yellow">Interior</span> Designs
                                        </h1>
                                    </div>
                                    <div class="slider-section-1-text">
                                        <p class="pregap-tecx">At Rahhim Designs, we transform your vision into reality
                                            with custom decor inspired by sub-continent, Arab, and Oriental art,
                                            creating spaces that embody beauty and meaning.</p>
                                        <p class="pregap-tecx">Our team brings your ideas to life with respect for
                                            cultural heritage, crafting spaces that reflect your unique vision and
                                            aspirations.</p>
                                    </div>
                                    <a href="" class="itg-button mar-top20">Explore Now</a>
                                    <a href="<?php echo e(url('contact_us')); ?>" class="itg-button mar-top20 mar-left15">Contact
                                        Us</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!--//========slider End=========//-->
        <!--//========About us section start=========//-->
        <section class="about-us-section pad-top100 pad-bottom100">
            <div class="container">
                <div class="row">
                    <div class="col-md-5 col-sm-12 col-xs-12">
                        <figure class="abouts-image">
                            <img src="assets/img/About/one.jpg" alt="" />
                        </figure>
                    </div>
                    <div class="col-md-7 col-sm-12 col-xs-12 about-box">
                        <h2 class="heading-color theme-title">About us</h2>
                        <p class="pregap-tecx">
                            At Rahhim Designs, we are dedicated to transforming your vision into breathtaking reality.
                            Specializing in custom interior decor and event decorations, we draw inspiration from the
                            timeless beauty of sub-continent, Arab and Oriental art and traditions, infusing each
                            project with sophistication, warmth, and individuality. Our mission is simple: to create the
                            home you've always dreamed of, curate events that leave a lasting impression, and craft
                            spaces that embody beauty and meaning.
                        </p>

                        <p class="pregap-tecx">
                            Whether you're looking to transform your home, elevate a business environment, or design a
                            memorable celebration, our expert team listens attentively to your desires and brings your
                            ideas to life with unparalleled attention to detail and artistry. Every project is
                            approached with deep respect for cultural heritage and a commitment to excellence, ensuring
                            that each space reflects your unique vision and aspirations.


                        </p>
                        <a href="" class="itg-button mar-top20">Read more</a>
                    </div>
                </div>
            </div>
        </section>
        <!--//========About us section End=========//-->
        <!--//========Our service section Start=========//-->

        <!--//========Our service section End=========//-->
        <!--//========projects section Start=========//-->
        <section class="categories-section">
            <div class="container">
                <!-- Category buttons -->
                <div class="row">
                    <div class="col-md-3">
                        <div class="filter btn btn-primary" data-category="all">All</div>
                    </div>
                    <div class="col-md-3">
                        <div class="filter btn btn-primary" data-category="interior">Interior Decor</div>
                    </div>
                    <div class="col-md-3">
                        <div class="filter btn btn-primary" data-category="event-decor">Event Decor</div>
                    </div>
                    <div class="col-md-3">
                        <div class="filter btn btn-primary" data-category="private-commission">Private Commission
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="filter btn btn-primary" data-category="bespoke-furniture">Bespoke Furniture</div>
                    </div>
                    <div class="col-md-3">
                        <div class="filter btn btn-primary" data-category="mosque-design">Mosque Designs</div>
                    </div>
                </div>



                <!-- Category sections -->
                <div class="category-sections">
                    <!-- Interior Decor Section -->
                    <div class="section interior" style="display: block;">
                        <div class="row image-row">
                            <div class="col-md-3 col-6 mb-3">
                                <img src="assets/img/Interior_Decor/1.jpg" alt="Interior Decor 1"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6 mb-3">
                                <img src="assets/img/Interior_Decor/2.jpg" alt="Interior Decor 2"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6 mb-3">
                                <img src="assets/img/Interior_Decor/3.jpg" alt="Interior Decor 3"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6 mb-3">
                                <img src="assets/img/Interior_Decor/4.jpg" alt="Interior Decor 4"
                                    class="img-fluid fixed-size">
                            </div>
                        </div>

                        <br>
                        <div class="row image-row">
                            <div class="col-md-3 col-6 mb-3">
                                <img src="assets/img/Interior_Decor/5.jpg" alt="Interior Decor 5"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6 mb-3">
                                <img src="assets/img/Interior_Decor/6.jpg" alt="Interior Decor 6"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6 mb-3">
                                <img src="assets/img/Interior_Decor/7.jpg" alt="Interior Decor 7"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6 mb-3">
                                <img src="assets/img/Interior_Decor/8.jpg" alt="Interior Decor 8"
                                    class="img-fluid fixed-size">
                            </div>
                        </div>
                    </div>

                    <!-- Event Decor Section -->
                    <div class="section event-decor" style="display: block;">
                        <div class="row">
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Event_Decor/1.jpg" alt="Event Decor 1"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Event_Decor/2.jpg" alt="Event Decor 2"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Event_Decor/3.jpg" alt="Event Decor 3"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Event_Decor/4.jpg" alt="Event Decor 4"
                                    class="img-fluid fixed-size">
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Event_Decor/5.jpg" alt="Event Decor 5"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Event_Decor/6.jpg" alt="Event Decor 6"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Event_Decor/7.jpg" alt="Event Decor 7"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Event_Decor/8.jpg" alt="Event Decor 8"
                                    class="img-fluid fixed-size">
                            </div>
                        </div>
                    </div>

                    <!-- Private Commission Section -->
                    <div class="section private-commission" style="display: block;">
                        <div class="row">
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Private_Commission/1.jpg" alt="Private Commission 1"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Private_Commission/2.jpg" alt="Private Commission 2"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Private_Commission/3.jpg" alt="Private Commission 3"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Private_Commission/4.jpg" alt="Private Commission 4"
                                    class="img-fluid fixed-size">
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Private_Commission/5.jpg" alt="Private Commission 5"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Private_Commission/6.jpg" alt="Private Commission 6"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Private_Commission/7.jpg" alt="Private Commission 7"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Private_Commission/8.jpg" alt="Private Commission 8"
                                    class="img-fluid fixed-size">
                            </div>
                        </div>
                    </div>

                    <!-- Bespoke Furniture Section -->
                    <div class="section bespoke-furniture" style="display: block;">
                        <div class="row">
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Bespoke_Furniture/1.jpg" alt="Bespoke Furniture 1"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Bespoke_Furniture/2.jpg" alt="Bespoke Furniture 2"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Bespoke_Furniture/3.jpg" alt="Bespoke Furniture 3"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Bespoke_Furniture/4.jpg" alt="Bespoke Furniture 4"
                                    class="img-fluid fixed-size">
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Bespoke_Furniture/5.jpg" alt="Bespoke Furniture 5"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Bespoke_Furniture/6.jpg" alt="Bespoke Furniture 6"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Bespoke_Furniture/7.jpg" alt="Bespoke Furniture 7"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Bespoke_Furniture/8.jpg" alt="Bespoke Furniture 8"
                                    class="img-fluid fixed-size">
                            </div>
                        </div>
                    </div>

                    <!-- Mosque Designs Section -->
                    <div class="section mosque-design" style="display: block;">
                        <div class="row">
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Mosque_Designs/1.jpg" alt="Mosque Design 1"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Mosque_Designs/2.jpg" alt="Mosque Design 2"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Mosque_Designs/3.jpg" alt="Mosque Design 3"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Mosque_Designs/4.jpg" alt="Mosque Design 4"
                                    class="img-fluid fixed-size">
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Mosque_Designs/5.jpg" alt="Mosque Design 5"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Mosque_Designs/6.jpg" alt="Mosque Design 6"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Mosque_Designs/7.jpg" alt="Mosque Design 7"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Mosque_Designs/8.jpg" alt="Mosque Design 8"
                                    class="img-fluid fixed-size">
                            </div>
                        </div>
                    </div>
                    <div class="section all" style="display: block;">
                        <div class="row">
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Mosque_Designs/1.jpg" alt="Mosque Design 1"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Mosque_Designs/2.jpg" alt="Mosque Design 2"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Mosque_Designs/3.jpg" alt="Mosque Design 3"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Mosque_Designs/4.jpg" alt="Mosque Design 4"
                                    class="img-fluid fixed-size">
                            </div>
                        </div>
                        <br>
                        <div class="row image-row">
                            <div class="col-md-3 col-6 mb-3">
                                <img src="assets/img/Interior_Decor/1.jpg" alt="Interior Decor 1"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6 mb-3">
                                <img src="assets/img/Interior_Decor/2.jpg" alt="Interior Decor 2"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6 mb-3">
                                <img src="assets/img/Interior_Decor/3.jpg" alt="Interior Decor 3"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6 mb-3">
                                <img src="assets/img/Interior_Decor/4.jpg" alt="Interior Decor 4"
                                    class="img-fluid fixed-size">
                            </div>
                        </div>

                        <br>
                        <div class="row image-row">
                            <div class="col-md-3 col-6 mb-3">
                                <img src="assets/img/Interior_Decor/5.jpg" alt="Interior Decor 5"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6 mb-3">
                                <img src="assets/img/Interior_Decor/6.jpg" alt="Interior Decor 6"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6 mb-3">
                                <img src="assets/img/Interior_Decor/7.jpg" alt="Interior Decor 7"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6 mb-3">
                                <img src="assets/img/Interior_Decor/8.jpg" alt="Interior Decor 8"
                                    class="img-fluid fixed-size">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Private_Commission/1.jpg" alt="Private Commission 1"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Private_Commission/2.jpg" alt="Private Commission 2"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Private_Commission/3.jpg" alt="Private Commission 3"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Private_Commission/4.jpg" alt="Private Commission 4"
                                    class="img-fluid fixed-size">
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Private_Commission/5.jpg" alt="Private Commission 5"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Private_Commission/6.jpg" alt="Private Commission 6"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Private_Commission/7.jpg" alt="Private Commission 7"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Private_Commission/8.jpg" alt="Private Commission 8"
                                    class="img-fluid fixed-size">
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Mosque_Designs/5.jpg" alt="Mosque Design 5"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Mosque_Designs/6.jpg" alt="Mosque Design 6"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Mosque_Designs/7.jpg" alt="Mosque Design 7"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6">
                                <img src="assets/img/Mosque_Designs/8.jpg" alt="Mosque Design 8"
                                    class="img-fluid fixed-size">
                            </div>
                        </div>
                        <div class="row image-row">
                            <div class="col-md-3 col-6 mb-3">
                                <img src="assets/img/Interior_Decor/1.jpg" alt="Interior Decor 1"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6 mb-3">
                                <img src="assets/img/Interior_Decor/2.jpg" alt="Interior Decor 2"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6 mb-3">
                                <img src="assets/img/Interior_Decor/3.jpg" alt="Interior Decor 3"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6 mb-3">
                                <img src="assets/img/Interior_Decor/4.jpg" alt="Interior Decor 4"
                                    class="img-fluid fixed-size">
                            </div>
                        </div>

                        <br>
                        <div class="row image-row">
                            <div class="col-md-3 col-6 mb-3">
                                <img src="assets/img/Interior_Decor/5.jpg" alt="Interior Decor 5"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6 mb-3">
                                <img src="assets/img/Interior_Decor/6.jpg" alt="Interior Decor 6"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6 mb-3">
                                <img src="assets/img/Interior_Decor/7.jpg" alt="Interior Decor 7"
                                    class="img-fluid fixed-size">
                            </div>
                            <div class="col-md-3 col-6 mb-3">
                                <img src="assets/img/Interior_Decor/8.jpg" alt="Interior Decor 8"
                                    class="img-fluid fixed-size">
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>


        <script>
            document.addEventListener("DOMContentLoaded", function() {
                const buttons = document.querySelectorAll('.filter');
                const sections = document.querySelectorAll('.category-sections .section');

                buttons.forEach(button => {
                    button.addEventListener('click', function() {
                        const category = this.getAttribute('data-category');

                        // If "All" is selected, display all sections
                        if (category === 'all') {
                            sections.forEach(section => section.style.display = 'block');
                        } else {
                            // Otherwise, only display the selected category section
                            sections.forEach(section => {
                                if (section.classList.contains(category)) {
                                    section.style.display = 'block';
                                } else {
                                    section.style.display = 'none';
                                }
                            });
                        }
                    });
                });
            });
        </script>

        <script>
            document.querySelectorAll('.filter').forEach(function(button) {
                button.addEventListener('click', function() {
                    const category = this.getAttribute('data-category');
                    document.querySelectorAll('.category-sections .section').forEach(function(section) {
                        if (section.classList.contains(category)) {
                            section.style.display = 'block';
                        } else {
                            section.style.display = 'none';
                        }
                    });
                });
            });
        </script>





        <script>
            window.addEventListener("load", function() {
                // alert('wa');
                // Find the button with the specified class and data attribute
                const allButton = document.querySelector(".filter[data-category='all']");

                if (allButton) {
                    // Trigger a click on the "All" button
                    allButton.click();
                }
            });
        </script>


        <!--//========projects section End=========//-->
        <!--//========banner box section Start=========//-->

        <!--//========banner box section End=========//-->

        <!--//========price section End=========//-->
        <!--//========testimony section Start=========//-->

        <!--//========testimony section End=========//-->
        <!--//========team section Start=========//-->

        <!--//========team section End=========//-->
        <!--//========facts section End=========//-->

        <!--//========facts section End=========//-->
        <!--//========blog post section Start=========//-->

        <!--//========blog poas section End=========//-->
        <!--//========pattern section Start=========//-->

        <!--//========pattern section End=========//-->
        <!--//========NEW-letter section Start=========//-->

        <!--//========NEW-letter section End=========//-->
        <!--//========footer section Strat=========//-->


        <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--//========footer section End=========//-->
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const filters = document.querySelectorAll('.filter'); // All category buttons
            const sections = document.querySelectorAll('.section'); // All category sections

            // Initially hide all sections
            sections.forEach(function(section) {
                section.style.display = 'none';
            });

            // Show the selected category's section
            filters.forEach(function(filter) {
                filter.addEventListener('click', function() {
                    const category = filter.getAttribute('data-category');

                    // Hide all sections first
                    sections.forEach(function(section) {
                        section.style.display = 'none';
                    });

                    // Show the clicked category section
                    const selectedSection = document.querySelector('.' + category);
                    if (selectedSection) {
                        selectedSection.style.display = 'block';
                    }
                });
            });
        });
    </script>
    <script>
        function redirectToWhatsApp() {
            // Replace with your WhatsApp number in international format (e.g., 1234567890)
            const phoneNumber = "1234567890";
            const url = `https://wa.me/${phoneNumber}`;

            // Open the WhatsApp link in a new tab
            window.open(url, '_blank');
        }
    </script>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="assets/plugin/menu-menu/js/hover-dropdown-menu.js"></script>
    <script src="assets/plugin/menu-menu/js/jquery.hover-dropdown-menu-addon.js"></script>
    <script src="assets/plugin/owl-carousel-slider/js/owl.carousel.min.js"></script>
    <script src="assets/plugin/fancyBox/js/jquery.fancybox.pack.js"></script>
    <script src="assets/plugin/fancyBox/js/jquery.fancybox-media.js"></script>
    <script type="text/javascript" src="assets/plugin/counter/js/jquery.countTo.js"></script>
    <script type="text/javascript" src="assets/plugin/counter/js/jquery.appear.js"></script>
    <script src="assets/plugin/mixitup/js/jquery.mixitup.js"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>
<?php /**PATH D:\RahimGallery\Website\backend\resources\views/welcome.blade.php ENDPATH**/ ?>