<div class="navbar-collapse collapse">
    <!-- nav -->
    <ul class="nav navbar-nav">
        <li>
            <a href="/">Home</a>
        </li>

        <li>
            <a href="<?php echo e(url('gallery')); ?>">Gallery</a>
        </li>
        <li>
            <a href="<?php echo e(url('about_us')); ?>">About Us</a>
        </li>


        <li>
            <a href="<?php echo e(url('contact_us')); ?>">contact</a>
        </li>
    </ul>
</div>
<?php /**PATH D:\RahimGallery\Website\backend\resources\views/navbar.blade.php ENDPATH**/ ?>