<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RAHHIM DESIGN</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            color: #333;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }

        .email-container {
            width: 100%;
            max-width: 600px;
            margin: 0 auto;
            background-color: #ffffff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .header {
            background-color: #0962ca;
            color: #ffffff;
            padding: 20px;
            text-align: center;
        }

        .header img {
            max-width: 150px;
            margin-bottom: 20px;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
            color: #fa8b1b;
        }

        .content {
            padding: 20px;
            line-height: 1.6;
        }

        .content h2 {
            color: #0962ca;
        }

        .content p {
            color: #333;
        }

        .content blockquote {
            margin: 15px 0;
            padding: 15px;
            background-color: #f0f4f9;
            border-left: 5px solid #0962ca;
            font-style: italic;
            color: #555;
        }

        .footer {
            background-color: #f0f4f9;
            color: #333;
            padding: 20px;
            text-align: center;
            font-size: 14px;
            border-top: 1px solid #e0e0e0;
        }

        .social-links {
            list-style: none;
            padding: 0;
            display: flex;
            justify-content: center;
            gap: 10px;
        }

        .social-links li a {
            text-decoration: none;
            font-size: 18px;
            color: #333;
        }

        .social-links li a:hover {
            color: #0962ca;
        }

        .back-link {
            text-align: center;
            margin-top: 20px;
        }

        .back-link a {
            color: #0962ca;
            text-decoration: none;
        }

        .back-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <div class="email-container">
        <div class="header">
            <img src="path_to_logo.png" alt="RAHHIM DESIGN Logo"> <!-- Add your logo image path here -->
            <h1>Thank You for Contacting Us!</h1>
        </div>

        <div class="content">
            <h2>Hi, {{ $name }}!</h2>
            <p>We appreciate you reaching out to us. Here’s a copy of your message:</p>

            <blockquote>
                "{{ $userMessage }}"
            </blockquote>

            <p>Our team will review your message and respond to you as soon as possible.</p>
            <p>If you need immediate assistance, feel free to contact our support team at any time.</p>
        </div>

        <div class="footer">
            <p>Best regards,</p>
            <p>The Support Team</p>
            <p>Company Name | Contact: support@example.com</p>

            <!-- Social Links -->
            <ul class="social-links">
                <li><a href="https://www.facebook.com/woodgallery?mibextid=LQQJ4d" target="_blank">
                        <i class="fa fa-facebook" aria-hidden="true"></i> Facebook
                    </a></li>
                <li><a href="https://www.instagram.com/rahhimdesign/profilecard/?igsh=MXZ1dWU1Njl1Nzh2YQ=="
                        target="_blank">
                        <i class="fa fa-instagram" aria-hidden="true"></i> Instagram
                    </a></li>
            </ul>

            <!-- Back Link -->
            <div class="back-link">
                <p><a href="https://yourwebsite.com" target="_blank">Back to Website</a></p>
                <!-- Adjust the URL accordingly -->
            </div>
        </div>
    </div>
</body>

</html>
