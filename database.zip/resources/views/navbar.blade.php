<div class="navbar-collapse collapse">
    <!-- nav -->
    <ul class="nav navbar-nav">
        <li><a href="/">Home</a></li>
        <li><a href="{{ url('gallery') }}">Gallery</a></li>
        <li><a href="{{ url('about_us') }}">About Us</a></li>
        <li><a href="{{ url('contact_us') }}">Contact</a></li>
    </ul>
</div>

